export type Page = 
  | 'home' 
  | 'explore' 
  | 'explore-sit'
  | 'explore-connect'
  | 'explore-party'
  | 'event-detail' 
  | 'book' 
  | 'booking-status'
  | 'onboarding' 
  | 'apply'
  | 'apply-pending'
  | 'mntase-apply'
  | 'mntase-pending'
  | 'join-movement'
  | 'create' 
  | 'curator-dashboard'
  | 'admin-dashboard'
  | 'safe-exit'
  | 'login'
  | 'signup';

export type UserRole = 'mntase' | 'curator' | 'admin';
export type ApplicationStatus = 'none' | 'pending' | 'approved' | 'rejected';

export interface UserProfile {
  name: string;
  intro: string;
  vibes: string[];
  avatar: string;
}

export interface Curator {
  name: string;
  avatar: string;
  since: string;
  bio: string;
}

export interface Guest {
  name: string;
  avatar: string;
  vibes: string[];
  intro?: string;
}

export interface Gathering {
  id: string;
  title: string;
  type: 'Come sit with us' | 'Come connect with us' | 'Come party with us';
  curator: Curator;
  date: string;
  time: string;
  endTime?: string;
  location: string;
  fullAddress?: string;
  price: number;
  capacity: number;
  spotsLeft: number;
  image: string;
  color: string;
  description: string;
  whatsIncluded: string[];
  houseRules: string[];
  confirmedGuests: Guest[];
}

export interface CuratorApplication {
  userId: string;
  name: string;
  email: string;
  reason: string;
  experienceType: string;
  status: ApplicationStatus;
  appliedDate: string;
}