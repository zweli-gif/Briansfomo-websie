import React, { useState } from 'react';
import { Page, Gathering, UserRole, UserProfile } from './types.ts';
import { GATHERINGS } from './constants.tsx';
import { Header } from './components/Header.tsx';
import Home from './pages/Home.tsx';
import Explore from './pages/Explore.tsx';
import EventDetail from './pages/EventDetail.tsx';
import SafeExit from './pages/SafeExit.tsx';
import CreateGathering from './pages/CreateGathering.tsx';
import CuratorApplication from './pages/CuratorApplication.tsx';
import AdminDashboard from './pages/AdminDashboard.tsx';
import MntaseApplication from './pages/MntaseApplication.tsx';
import Onboarding from './pages/Onboarding.tsx';
import JoinMovementHub from './pages/JoinMovementHub.tsx';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedEvent, setSelectedEvent] = useState<Gathering | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [bookingStatus, setBookingStatus] = useState<'none' | 'processing' | 'applied'>('none');

  const handleSelectEvent = (event: Gathering) => {
    setSelectedEvent(event);
    setBookingStatus('none');
    setCurrentPage('event-detail');
    window.scrollTo(0, 0);
  };

  const handleBookingStart = () => {
    if (!userProfile) {
      setCurrentPage('onboarding');
    } else {
      setBookingStatus('processing');
      setTimeout(() => {
        setBookingStatus('applied');
        setCurrentPage('booking-status');
      }, 1500);
    }
    window.scrollTo(0, 0);
  };

  const renderPage = () => {
    // Handle category-specific explore routing
    if (currentPage.startsWith('explore')) {
      let activeCatId: string | null = null;
      if (currentPage === 'explore-sit') activeCatId = 'sit';
      if (currentPage === 'explore-connect') activeCatId = 'connect';
      if (currentPage === 'explore-party') activeCatId = 'party';
      
      return (
        <Explore 
          onSelectEvent={handleSelectEvent} 
          onCreateRedirect={() => setCurrentPage('create')} 
          activeCategoryId={activeCatId}
        />
      );
    }

    switch (currentPage) {
      case 'home': return <Home setPage={setCurrentPage} />;
      case 'event-detail': 
        return selectedEvent ? (
          <EventDetail 
            event={selectedEvent} 
            onApply={handleBookingStart} 
            setPage={setCurrentPage} 
          />
        ) : null;
      case 'onboarding': 
        return <Onboarding onComplete={(p) => { 
          setUserProfile(p); 
          if (selectedEvent) setCurrentPage('event-detail');
          else setCurrentPage('home');
        }} />;
      case 'join-movement': return <JoinMovementHub setPage={setCurrentPage} />;
      case 'mntase-apply': return <MntaseApplication onSubmit={() => setCurrentPage('mntase-pending')} />;
      case 'apply': return <CuratorApplication onSubmit={() => setCurrentPage('apply-pending')} />;
      case 'safe-exit': return <SafeExit />;
      case 'create': return <CreateGathering userProfile={userProfile} />;
      case 'mntase-pending':
        return (
          <div className="max-w-2xl mx-auto px-4 py-40 text-center space-y-8 animate-in fade-in zoom-in duration-500">
            <div className="size-24 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-6xl">verified</span>
            </div>
            <h2 className="text-4xl font-black tracking-tight">Belonging is around the corner.</h2>
            <p className="text-xl text-navy/60 font-medium leading-relaxed">
              We've received your application to join the movement. Our community vetting process keeps the table safe for everyone. You'll hear from us soon!
            </p>
            <button onClick={() => setCurrentPage('home')} className="bg-navy text-white font-black px-10 py-4 rounded-2xl shadow-xl">Back to Home</button>
          </div>
        );
      case 'booking-status':
        return (
          <div className="max-w-2xl mx-auto px-4 py-40 text-center space-y-8 animate-in fade-in duration-500">
            <div className="size-24 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-6xl">mark_email_read</span>
            </div>
            <h2 className="text-4xl font-black tracking-tight">Application Sent!</h2>
            <p className="text-xl text-navy/60 font-medium leading-relaxed">
              The curator for <strong>{selectedEvent?.title}</strong> will review your intro and vibes. You'll be notified via email once approved to pay and get the address.
            </p>
            <button onClick={() => setCurrentPage('explore')} className="bg-navy text-white font-black px-10 py-4 rounded-2xl shadow-xl">Browse more events</button>
          </div>
        );
      default: return <Home setPage={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-primary/20">
      <Header currentPage={currentPage} setPage={setCurrentPage} userProfile={userProfile} />
      <main className="flex-grow">{renderPage()}</main>
      
      <footer className="bg-navy text-white/40 py-20 px-4 md:px-20 mt-auto border-t border-white/5">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="flex flex-col md:flex-row justify-between items-start gap-12">
            <div className="space-y-6">
              <div className="flex items-center gap-2 text-primary">
                <div className="size-8">
                  <svg fill="currentColor" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 42.4379C4 42.4379 14.0962 36.0744 24 41.1692C35.0664 46.8624 44 42.2078 44 42.2078L44 7.01134C44 7.01134 35.068 11.6577 24.0031 5.96913C14.0971 0.876274 4 7.27094 4 7.27094L4 42.4379Z"></path>
                  </svg>
                </div>
                <h2 className="text-white font-black text-2xl tracking-tighter uppercase">BRIANSFOMO</h2>
              </div>
              <p className="text-xl italic font-medium text-white/60">"Come be with us, Mntase."</p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-16 text-left">
              <div className="space-y-4">
                <p className="text-xs font-black text-white/20 uppercase tracking-widest">Platform</p>
                <ul className="space-y-2 text-sm font-bold text-white/60">
                  <li><button onClick={() => setCurrentPage('explore')} className="hover:text-primary">Browse Events</button></li>
                  <li><button onClick={() => setCurrentPage('join-movement')} className="hover:text-primary">Join the Movement</button></li>
                  <li><button onClick={() => setCurrentPage('apply')} className="hover:text-primary">Become a Curator</button></li>
                </ul>
              </div>
              <div className="space-y-4">
                <p className="text-xs font-black text-white/20 uppercase tracking-widest">Belonging</p>
                <ul className="space-y-2 text-sm font-bold text-white/60">
                  <li><button onClick={() => setCurrentPage('safe-exit')} className="hover:text-primary">Safe Exit Protocol</button></li>
                  <li><button className="hover:text-primary">Trust & Safety</button></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-xs font-black uppercase tracking-widest">
            <p>© 2026 BRIANSFOMO. Curated with love in South Africa.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-white">Privacy</a>
              <a href="#" className="hover:text-white">Terms</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
