import React from 'react';
import { GATHERINGS, CATEGORIES } from '../constants';
import { Gathering } from '../types';

interface ExploreProps {
  onSelectEvent: (event: Gathering) => void;
  onCreateRedirect: () => void;
  activeCategoryId?: string | null;
}

const Explore: React.FC<ExploreProps> = ({ onSelectEvent, onCreateRedirect, activeCategoryId }) => {
  const filteredCategories = activeCategoryId 
    ? CATEGORIES.filter(c => c.id === activeCategoryId)
    : CATEGORIES;

  const isCategoryView = !!activeCategoryId;
  const activeCatObj = activeCategoryId ? CATEGORIES.find(c => c.id === activeCategoryId) : null;

  return (
    <div className="animate-in fade-in duration-500">
      {isCategoryView && activeCatObj && (
        <div className={`py-20 md:py-32 bg-background border-b border-[#e5dddc] relative overflow-hidden`}>
          <div className="absolute top-0 right-0 w-1/3 h-full bg-primary/5 blur-3xl -z-0"></div>
          <div className="max-w-7xl mx-auto px-4 relative z-10">
            <div className="flex flex-col items-center text-center space-y-6">
               <div className="size-20 rounded-3xl bg-primary/10 text-primary flex items-center justify-center shadow-sm">
                  <span className="material-symbols-outlined text-5xl">{activeCatObj.icon}</span>
               </div>
               <h1 className="text-6xl md:text-8xl font-black tracking-tighter">{activeCatObj.name}</h1>
               <p className="text-2xl text-navy/60 font-medium max-w-2xl italic leading-relaxed">
                 {activeCatObj.description}
               </p>
            </div>
          </div>
        </div>
      )}

      {!isCategoryView && (
        <div className="max-w-7xl mx-auto px-4 py-20 text-center space-y-6">
          <h2 className="text-6xl md:text-8xl font-black tracking-tighter">Find Your Table</h2>
          <p className="text-xl text-navy/60 font-medium max-w-2xl mx-auto">
            Intimate community gatherings hosted by real people in spaces across the world. Choose your rhythm.
          </p>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 py-16 space-y-24">
        {filteredCategories.map((cat) => {
          const events = GATHERINGS.filter(g => g.type === cat.name);
          return (
            <section key={cat.id} className="space-y-12">
              {!isCategoryView && (
                <div className="border-l-4 border-primary pl-8 space-y-3">
                  <div className="flex items-center gap-4">
                    <div className="size-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                      <span className="material-symbols-outlined text-3xl">{cat.icon}</span>
                    </div>
                    <h3 className="text-4xl md:text-5xl font-black tracking-tight">{cat.name}</h3>
                  </div>
                  <p className="text-xl text-navy/60 font-medium max-w-2xl leading-relaxed">{cat.description}</p>
                </div>
              )}

              {events.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-10">
                  {events.map((g) => (
                    <div 
                      key={g.id} 
                      onClick={() => onSelectEvent(g)}
                      className="group cursor-pointer bg-white rounded-[3rem] overflow-hidden border border-[#e5dddc] hover:shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] transition-all hover:-translate-y-2"
                    >
                      <div className="relative aspect-[16/9] overflow-hidden">
                        <img src={g.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt={g.title} />
                        <div className="absolute top-8 left-8">
                          <span className="bg-white/95 backdrop-blur-md text-navy text-xs font-black px-5 py-2.5 rounded-full uppercase tracking-widest shadow-xl">
                            {g.type}
                          </span>
                        </div>
                      </div>
                      <div className="p-10 space-y-8">
                        <div className="space-y-4">
                          <h3 className="text-3xl md:text-4xl font-black group-hover:text-primary transition-colors leading-tight">{g.title}</h3>
                          <div className="flex items-center gap-4">
                            <img src={g.curator.avatar} className="size-10 rounded-full border-2 border-primary/20" alt={g.curator.name} />
                            <p className="text-base font-bold text-navy/60">Curated by {g.curator.name}</p>
                          </div>
                        </div>
                        <div className="flex justify-between items-center pt-8 border-t border-[#f4f1f0]">
                          <div className="space-y-1">
                            <p className="text-xs font-black text-navy/40 uppercase tracking-widest">Price per seat</p>
                            <p className="text-3xl font-black text-primary">R{g.price}</p>
                          </div>
                          <div className="text-right space-y-1">
                            <p className="text-xs font-black text-navy/40 uppercase tracking-widest">When</p>
                            <p className="text-lg font-bold">{g.date}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-white border-2 border-dashed border-[#e5dddc] rounded-[3rem] py-24 text-center space-y-6 shadow-inner">
                  <div className="size-20 rounded-3xl bg-navy/5 flex items-center justify-center mx-auto text-navy/20">
                    <span className="material-symbols-outlined text-5xl">auto_awesome</span>
                  </div>
                  <div className="space-y-2">
                    <p className="text-2xl font-black text-navy/40 italic">There are no gatherings in this space yet.</p>
                    <p className="text-navy/30 font-medium">Be the first to create the magic here.</p>
                  </div>
                  <button 
                    onClick={onCreateRedirect}
                    className="bg-navy text-white font-black px-10 py-4 rounded-2xl shadow-xl transition-all hover:scale-105 active:scale-95"
                  >
                    Create a Gathering
                  </button>
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
};

export default Explore;