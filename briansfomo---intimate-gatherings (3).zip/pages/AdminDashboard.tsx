
import React from 'react';
import { CuratorApplication } from '../types';

interface AdminDashboardProps {
  applications: CuratorApplication[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ applications, onApprove, onReject }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-12">
      <h2 className="text-5xl font-black tracking-tight">Admin Portal</h2>
      <div className="bg-white rounded-3xl border border-[#e5dddc] overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-background px-8">
            <tr>
              <th className="px-8 py-4 uppercase text-xs font-black text-navy/40">Applicant</th>
              <th className="px-8 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {applications.map(app => (
              <tr key={app.userId} className="border-t">
                <td className="px-8 py-4 font-bold">{app.name}</td>
                <td className="px-8 py-4 text-right">
                  <button onClick={() => onApprove(app.userId)} className="bg-sage text-white px-4 py-2 rounded-xl text-xs font-black uppercase">Approve</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Fix: Adding default export for AdminDashboard
export default AdminDashboard;
