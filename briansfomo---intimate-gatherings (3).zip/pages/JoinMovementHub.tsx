
import React from 'react';
import { Page } from '../types';

interface JoinMovementHubProps {
  setPage: (page: Page) => void;
}

const JoinMovementHub: React.FC<JoinMovementHubProps> = ({ setPage }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center space-y-6">
        <h1 className="text-6xl md:text-8xl font-black tracking-tighter">Choose Your Path</h1>
        <p className="text-2xl text-navy/60 font-medium max-w-2xl mx-auto">
          Every great community is built by two kinds of people: those who bring the spirit, and those who hold the space.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="bg-white border border-[#e5dddc] rounded-[4rem] p-10 md:p-16 shadow-xl hover:shadow-2xl transition-all flex flex-col justify-between group">
          <div className="space-y-8">
            <div className="size-20 rounded-[2rem] bg-primary/10 text-primary flex items-center justify-center transition-transform group-hover:scale-110">
              <span className="material-symbols-outlined text-5xl">person_pin</span>
            </div>
            <div className="space-y-4">
              <h2 className="text-4xl md:text-5xl font-black">Become an Mntase</h2>
              <p className="text-xl text-navy/60 font-medium leading-relaxed">
                Join as a guest to find intimate tables, make real friends, and experience the healing power of community.
              </p>
            </div>
            <ul className="space-y-4 pt-4">
              {['Vetted access to private gatherings', 'Curate your personal vibe profile', 'Protected by Safe Exit Protocol', 'Connect with like-minded humans'].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-lg font-bold text-navy/80">
                  <span className="material-symbols-outlined text-primary">check_circle</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <button onClick={() => setPage('mntase-apply')} className="mt-12 w-full h-20 bg-primary text-white font-black text-2xl rounded-[2rem] shadow-xl hover:bg-primary/90 active:scale-95 transition-all">Apply to Join</button>
        </div>

        <div className="bg-navy text-white rounded-[4rem] p-10 md:p-16 shadow-xl hover:shadow-2xl transition-all flex flex-col justify-between group">
          <div className="space-y-8">
            <div className="size-20 rounded-[2rem] bg-sage/20 text-sage flex items-center justify-center transition-transform group-hover:scale-110">
              <span className="material-symbols-outlined text-5xl">auto_awesome</span>
            </div>
            <div className="space-y-4">
              <h2 className="text-4xl md:text-5xl font-black text-white">Become a Curator</h2>
              <p className="text-xl text-white/60 font-medium leading-relaxed">
                Open your table, share your story, and build a sustainable income while fostering global belonging.
              </p>
            </div>
            <ul className="space-y-4 pt-4">
              {['Earn money from every gathering', 'Total control over guest vetting', 'Tools to manage intimate events', 'Build a community reputation'].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-lg font-bold text-white/80">
                  <span className="material-symbols-outlined text-sage">verified</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <button onClick={() => setPage('apply')} className="mt-12 w-full h-20 bg-sage text-white font-black text-2xl rounded-[2rem] shadow-xl hover:bg-sage/90 active:scale-95 transition-all">Start Hosting</button>
        </div>
      </div>
    </div>
  );
};

// Fix: Ensuring default export is present
export default JoinMovementHub;
