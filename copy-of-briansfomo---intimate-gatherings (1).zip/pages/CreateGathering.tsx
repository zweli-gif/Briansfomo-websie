import React from 'react';
import { UserProfile } from '../types';

interface CreateGatheringProps {
  userProfile?: UserProfile | null;
}

const CreateGathering: React.FC<CreateGatheringProps> = ({ userProfile }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
      <div className="text-center space-y-3">
        <h2 className="text-4xl md:text-5xl font-black tracking-tight">Create Your Gathering</h2>
        <p className="text-navy/60 text-xl italic">"Share your vibe, your story, your ubuntu."</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
        <div className="lg:col-span-2">
          <section className="bg-white p-6 md:p-10 rounded-3xl border border-[#e5dddc] shadow-sm space-y-8">
            <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <label className="flex flex-col gap-2">
                  <span className="text-xs font-black text-navy/40 uppercase tracking-widest">Event Type</span>
                  <select className="h-14 rounded-xl border-[#e5dddc] px-4 bg-background/30 font-bold">
                    <option>Come sit with us (Dining)</option>
                    <option>Come connect with us (Activity)</option>
                    <option>Come party with us (Celebration)</option>
                  </select>
                </label>
                <label className="flex flex-col gap-2">
                  <span className="text-xs font-black text-navy/40 uppercase tracking-widest">Gathering Title</span>
                  <input className="h-14 rounded-xl border-[#e5dddc] px-4 bg-background/30" placeholder="e.g. Sunday Jazz & Soul" type="text" />
                </label>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <label className="flex flex-col gap-2">
                  <span className="text-xs font-black text-navy/40 uppercase tracking-widest">Date</span>
                  <input className="h-14 rounded-xl border-[#e5dddc] px-4 bg-background/30" type="date" />
                </label>
                <label className="flex flex-col gap-2">
                  <span className="text-xs font-black text-navy/40 uppercase tracking-widest">Start Time</span>
                  <input className="h-14 rounded-xl border-[#e5dddc] px-4 bg-background/30" type="time" />
                </label>
              </div>
              <button className="w-full h-16 bg-primary text-white font-black text-xl rounded-2xl shadow-xl transition-all">Publish Gathering</button>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
};

export default CreateGathering;