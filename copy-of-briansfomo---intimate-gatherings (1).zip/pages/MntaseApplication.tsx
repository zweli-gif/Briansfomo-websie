import React, { useState } from 'react';

interface MntaseApplicationProps {
  onSubmit: (data: any) => void;
}

const MntaseApplication: React.FC<MntaseApplicationProps> = ({ onSubmit }) => {
  const [method, setMethod] = useState<'reference' | 'call'>('reference');

  return (
    <div className="max-w-4xl mx-auto px-4 py-20 space-y-12 animate-in fade-in">
      <h1 className="text-5xl font-black text-center">Join as Mntase</h1>
      <div className="flex justify-center gap-4">
        <button onClick={() => setMethod('reference')} className={`px-8 py-3 rounded-2xl font-black ${method === 'reference' ? 'bg-primary text-white' : 'bg-white text-navy/40 border'}`}>Reference</button>
        <button onClick={() => setMethod('call')} className={`px-8 py-3 rounded-2xl font-black ${method === 'call' ? 'bg-sage text-white' : 'bg-white text-navy/40 border'}`}>Vetting Call</button>
      </div>
      <form className="bg-white p-12 rounded-[2.5rem] border border-[#e5dddc] shadow-xl space-y-8" onSubmit={(e) => { e.preventDefault(); onSubmit({ method }); }}>
        <input required className="w-full h-14 rounded-xl border-[#e5dddc] px-4" placeholder="Full Name" type="text" />
        <button className="w-full h-16 bg-navy text-white font-black rounded-2xl shadow-xl uppercase tracking-widest">Apply to Join</button>
      </form>
    </div>
  );
};

export default MntaseApplication;