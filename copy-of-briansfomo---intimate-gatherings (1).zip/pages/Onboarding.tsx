import React, { useState } from 'react';
import { VIBE_PILLS } from '../constants';
import { UserProfile } from '../types';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [name, setName] = useState('');
  const [intro, setIntro] = useState('');
  const [selectedVibes, setSelectedVibes] = useState<string[]>([]);

  const toggleVibe = (vibe: string) => {
    if (selectedVibes.includes(vibe)) {
      setSelectedVibes(selectedVibes.filter(v => v !== vibe));
    } else if (selectedVibes.length < 5) {
      setSelectedVibes([...selectedVibes, vibe]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete({ name, intro, vibes: selectedVibes, avatar: `https://i.pravatar.cc/150?u=${name}` });
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-20 space-y-12">
      <h1 className="text-5xl font-black text-center tracking-tighter">Your Story</h1>
      <form className="bg-white p-12 rounded-[2.5rem] border border-[#e5dddc] shadow-xl space-y-8" onSubmit={handleSubmit}>
        <input required value={name} onChange={(e) => setName(e.target.value)} className="w-full h-14 rounded-xl border-[#e5dddc] px-4 font-bold" placeholder="Name" />
        <input required value={intro} onChange={(e) => setIntro(e.target.value)} className="w-full h-14 rounded-xl border-[#e5dddc] px-4 italic" placeholder="One sentence intro" />
        <div className="flex flex-wrap gap-2">
          {VIBE_PILLS.map(v => (
            <button key={v} type="button" onClick={() => toggleVibe(v)} className={`px-4 py-2 rounded-full text-xs font-bold ${selectedVibes.includes(v) ? 'bg-primary text-white' : 'bg-background text-navy/40'}`}>{v}</button>
          ))}
        </div>
        <button className="w-full h-16 bg-navy text-white font-black rounded-2xl shadow-xl">Complete Profile</button>
      </form>
    </div>
  );
};

export default Onboarding;