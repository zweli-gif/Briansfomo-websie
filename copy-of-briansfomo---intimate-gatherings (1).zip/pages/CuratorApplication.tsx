import React from 'react';

interface CuratorApplicationProps {
  onSubmit: (data: any) => void;
}

const CuratorApplication: React.FC<CuratorApplicationProps> = ({ onSubmit }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-20 space-y-12 animate-in fade-in">
      <h1 className="text-5xl font-black text-center">Become a Curator</h1>
      <div className="bg-white p-12 rounded-[2.5rem] border border-[#e5dddc] shadow-xl">
        <form className="space-y-8" onSubmit={(e) => { e.preventDefault(); onSubmit({}); }}>
          <label className="flex flex-col gap-2">
            <span className="text-xs font-black text-navy/40 uppercase tracking-widest">Why host?</span>
            <textarea className="rounded-xl border-[#e5dddc] p-4 bg-background/30 min-h-[120px]" placeholder="Tell us about your passion..."></textarea>
          </label>
          <button className="w-full h-16 bg-primary text-white font-black text-xl rounded-2xl shadow-xl">Apply now</button>
        </form>
      </div>
    </div>
  );
};

export default CuratorApplication;