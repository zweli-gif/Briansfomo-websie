import React from 'react';
import { Page } from '../types';

interface HomeProps {
  setPage: (page: Page) => void;
}

const Home: React.FC<HomeProps> = ({ setPage }) => {
  return (
    <div className="pb-24">
      <div className="bg-primary text-white text-center py-3 px-4 text-sm font-black tracking-widest uppercase">
        Belonging has no borders — <button onClick={() => setPage('explore')} className="underline">Find a table in your city</button>
      </div>

      <section className="px-4 pt-10">
        <div 
          className="relative min-h-[650px] max-w-7xl mx-auto flex flex-col items-center justify-center text-center p-8 rounded-[3rem] overflow-hidden shadow-2xl bg-cover bg-center"
          style={{ backgroundImage: `linear-gradient(rgba(26, 42, 58, 0.5) 0%, rgba(231, 107, 85, 0.7) 100%), url(https://images.unsplash.com/photo-1528605248644-14dd04322a11?auto=format&fit=crop&q=80&w=1200)` }}
        >
          <div className="z-10 space-y-6">
            <h1 className="text-white text-5xl md:text-8xl font-black tracking-tighter max-w-4xl animate-in fade-in slide-in-from-bottom-4 duration-700">
              Curated gatherings anywhere.
            </h1>
            <p className="text-white/95 text-xl md:text-3xl font-medium max-w-2xl mx-auto drop-shadow-md">
              A global movement ending loneliness through the spirit of Ubuntu.
            </p>
            <div className="flex flex-wrap gap-4 justify-center pt-8">
              <button 
                onClick={() => setPage('explore')}
                className="bg-white text-navy font-black h-16 px-12 rounded-2xl shadow-xl transition-all hover:scale-105 active:scale-95"
              >
                Find a Gathering
              </button>
              <button 
                onClick={() => setPage('join-movement')}
                className="bg-navy/80 backdrop-blur-md text-white border border-white/20 font-black h-16 px-12 rounded-2xl shadow-xl transition-all hover:scale-105 active:scale-95"
              >
                Join the Movement
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 pt-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
           <div className="space-y-8">
              <span className="text-primary font-black uppercase tracking-widest text-sm">The Vision</span>
              <h2 className="text-4xl md:text-7xl font-black tracking-tight leading-tight">
                Rebuilding intimacy in an isolated world.
              </h2>
              <div className="space-y-6 text-xl text-navy/70 leading-relaxed font-medium">
                <p>
                  Brian's Fomo was born from a simple realization: we are more "connected" than ever, yet more alone. The "Fomo" we talk about isn't about missing a party; it's about missing out on the essential human experience of belonging.
                </p>
                <p>
                  We facilitate small, high-trust gatherings where the only requirement is to show up as yourself. No resumes, no status, just the spirit of <strong>Ubuntu</strong>—I am because we are.
                </p>
              </div>
           </div>
           <div className="relative">
              <div className="aspect-[4/5] rounded-[4rem] overflow-hidden shadow-2xl">
                 <img src="https://images.unsplash.com/photo-1543807535-eceef0bc6599?auto=format&fit=crop&q=80&w=800" alt="Gathering" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-8 -left-8 bg-white p-8 rounded-3xl shadow-xl border border-[#e5dddc] max-w-xs animate-in slide-in-from-left-4">
                 <p className="italic font-bold text-navy/80 text-lg">"The cure for loneliness isn't more people—it's more presence."</p>
              </div>
           </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 pt-48 text-center space-y-12">
        <h2 className="text-5xl md:text-7xl font-black tracking-tight leading-tight">Ready to find your table?</h2>
        <div className="flex flex-wrap gap-6 justify-center">
          <button onClick={() => setPage('explore')} className="bg-primary text-white font-black h-20 px-16 rounded-[2rem] text-2xl shadow-2xl hover:scale-105 active:scale-95 transition-all">Browse Gatherings</button>
          <button onClick={() => setPage('join-movement')} className="bg-navy text-white font-black h-20 px-16 rounded-[2rem] text-2xl shadow-2xl hover:scale-105 active:scale-95 transition-all">Join Movement</button>
        </div>
      </section>
    </div>
  );
};

export default Home;