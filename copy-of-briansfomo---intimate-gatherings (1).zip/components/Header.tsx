import React, { useState } from 'react';
import { Page, UserProfile } from '../types';
import { CATEGORIES } from '../constants';

interface HeaderProps {
  currentPage: Page;
  setPage: (page: Page) => void;
  userRole?: 'mntase' | 'curator' | 'admin';
  userProfile?: UserProfile | null;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, setPage, userRole = 'mntase', userProfile }) => {
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);
  const [copied, setCopied] = useState(false);

  const getCategoryPage = (id: string): Page => {
    if (id === 'sit') return 'explore-sit';
    if (id === 'connect') return 'explore-connect';
    if (id === 'party') return 'explore-party';
    return 'explore';
  };

  const handleShare = async () => {
    const shareData = {
      title: "Briansfomo - Intimate Gatherings",
      text: "Check out this prototype for Briansfomo: Intimate community gatherings built on Ubuntu.",
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log("Share cancelled or failed", err);
      }
    } else {
      try {
        await navigator.clipboard.writeText(window.location.href);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        alert("Could not copy link. Please copy the URL from your browser address bar.");
      }
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#e5dddc] bg-white/90 backdrop-blur-md px-4 md:px-20 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div 
          className="flex items-center gap-2 text-primary cursor-pointer"
          onClick={() => setPage('home')}
        >
          <div className="size-8">
            <svg fill="currentColor" viewBox="0 0 48 48" xmlns="http://www.sum.org/2000/svg">
              <path d="M4 42.4379C4 42.4379 14.0962 36.0744 24 41.1692C35.0664 46.8624 44 42.2078 44 42.2078L44 7.01134C44 7.01134 35.068 11.6577 24.0031 5.96913C14.0971 0.876274 4 7.27094 4 7.27094L4 42.4379Z"></path>
            </svg>
          </div>
          <h1 className="text-xl font-black leading-tight tracking-tight text-navy">BRIANSFOMO</h1>
        </div>

        <nav className="hidden md:flex items-center gap-6 font-bold text-sm">
          <div 
            className="relative"
            onMouseEnter={() => setShowCategoryDropdown(true)}
            onMouseLeave={() => setShowCategoryDropdown(false)}
          >
            <button 
              className={`hover:text-primary transition-colors flex items-center gap-1 py-2 ${currentPage.startsWith('explore') ? 'text-primary' : ''}`}
            >
              Gatherings
              <span className="material-symbols-outlined text-sm">expand_more</span>
            </button>
            {showCategoryDropdown && (
              <div className="absolute left-0 mt-0 w-64 bg-white border border-[#e5dddc] rounded-2xl shadow-2xl py-3 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
                <button 
                  onClick={() => { setPage('explore'); setShowCategoryDropdown(false); }}
                  className="w-full text-left px-4 py-3 text-sm font-black hover:bg-background border-b border-[#f4f1f0]"
                >
                  View All Gatherings
                </button>
                {CATEGORIES.map(cat => (
                  <button 
                    key={cat.id}
                    onClick={() => { setPage(getCategoryPage(cat.id)); setShowCategoryDropdown(false); }}
                    className="w-full text-left px-4 py-3 text-sm font-bold hover:bg-background flex flex-col gap-0.5"
                  >
                    <span className="flex items-center gap-2">
                       <span className="material-symbols-outlined text-lg text-primary">{cat.icon}</span>
                       {cat.name}
                    </span>
                    <span className="text-[10px] text-navy/40 font-medium ml-7">{cat.description.substring(0, 40)}...</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {userRole === 'mntase' && (
            <button onClick={() => setPage('join-movement')} className={`hover:text-primary transition-colors py-2 ${currentPage === 'join-movement' ? 'text-primary underline decoration-2 underline-offset-8' : ''}`}>Join Movement</button>
          )}
          
          {userRole === 'curator' && (
            <button onClick={() => setPage('curator-dashboard')} className="hover:text-primary transition-colors py-2">Curator Dashboard</button>
          )}

          <div className="h-6 w-px bg-[#e5dddc] mx-2"></div>

          <button 
            onClick={handleShare}
            className="flex items-center gap-2 text-navy/60 hover:text-primary transition-colors"
          >
            <span className="material-symbols-outlined text-lg">
              {copied ? 'check' : 'share'}
            </span>
            <span className="text-xs uppercase tracking-widest font-black">{copied ? 'Copied!' : 'Share'}</span>
          </button>

          <div className="relative">
            <div 
              className="size-10 rounded-full border-2 border-primary/20 bg-cover bg-center cursor-pointer hover:border-primary transition-all overflow-hidden bg-background" 
              style={{ backgroundImage: userProfile ? `url(${userProfile.avatar})` : `url(https://i.pravatar.cc/100?u=brian)` }}
              onClick={() => setShowUserDropdown(!showUserDropdown)}
            />
            {showUserDropdown && (
              <div className="absolute right-0 mt-3 w-56 bg-white border border-[#e5dddc] rounded-2xl shadow-2xl py-2 overflow-hidden animate-in slide-in-from-top-2 duration-200">
                <button onClick={() => { setPage('onboarding'); setShowUserDropdown(false); }} className="w-full text-left px-4 py-3 text-sm font-bold hover:bg-background flex items-center gap-2">
                  <span className="material-symbols-outlined text-lg">person</span> {userProfile?.name || 'My Profile'}
                </button>
                <button onClick={() => { setPage('safe-exit'); setShowUserDropdown(false); }} className="w-full text-left px-4 py-3 text-sm font-bold hover:bg-background flex items-center gap-2">
                  <span className="material-symbols-outlined text-lg">door_open</span> Safe Exit Protocol
                </button>
                <div className="border-t border-[#e5dddc] my-1"></div>
                <button onClick={() => { setPage('login'); setShowUserDropdown(false); }} className="w-full text-left px-4 py-3 text-sm font-bold text-red-500 hover:bg-red-50 flex items-center gap-2">
                  <span className="material-symbols-outlined text-lg">logout</span> Log Out
                </button>
              </div>
            )}
          </div>
        </nav>

        <div className="flex items-center gap-4 md:hidden">
          <button onClick={handleShare} className="text-navy/60">
             <span className="material-symbols-outlined">{copied ? 'check' : 'share'}</span>
          </button>
          <button className="text-navy" onClick={() => setPage('join-movement')}>
            <span className="material-symbols-outlined">menu</span>
          </button>
        </div>
      </div>
    </header>
  );
};