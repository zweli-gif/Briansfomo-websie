import { Gathering } from './types';

export const CATEGORIES = [
  {
    id: 'sit',
    name: 'Come sit with us',
    description: 'Shared meals and deep conversations around a communal table.',
    icon: 'restaurant'
  },
  {
    id: 'connect',
    name: 'Come connect with us',
    description: 'Movement, learning, and shared growth through activities like yoga, walks, and talks.',
    icon: 'diversity_1'
  },
  {
    id: 'party',
    name: 'Come party with us',
    description: 'Celebrations, music, and the vibrant pulse of our community—from mgidi invites to club hopping.',
    icon: 'celebration'
  }
];

export const VIBE_PILLS = [
  'Deep Conversations', 'Light & Playful', 'Good Listener', 'Storyteller', 'Quiet Presence',
  'Foodie', 'Music Lover', 'Bookworm', 'Creative Soul', 'Wellness Minded',
  'First Timer', 'Connector', 'Solo Explorer', 'Regular Host', 'Open Book'
];

export const GATHERINGS: Gathering[] = [
  {
    id: '1',
    title: 'Sunday Soul Food & Jazz',
    type: 'Come sit with us',
    curator: {
      name: 'Thabo',
      avatar: 'https://picsum.photos/seed/thabo/100/100',
      since: '2023',
      bio: "Keeping the spirit of Ubuntu alive through food and music."
    },
    date: 'Sunday, Feb 14',
    time: '14:00',
    endTime: '18:00',
    location: 'Soweto',
    fullAddress: '42 Vilakazi St, Orlando West, Soweto',
    price: 250,
    capacity: 8,
    spotsLeft: 3,
    image: 'https://images.unsplash.com/photo-1528605248644-14dd04322a11?auto=format&fit=crop&q=80&w=800',
    color: 'bg-primary',
    description: "Join us for a slow afternoon of traditional home-cooked soul food and South African jazz vinyls. We'll start with a communal prayer and sharing of bread.",
    whatsIncluded: ['3-course meal', 'Drinks', 'Live Vinyl Set'],
    houseRules: ['Shoes off at the door', 'No phones at the table'],
    confirmedGuests: [
      { name: 'Lerato', avatar: 'https://i.pravatar.cc/150?u=1', vibes: ['Good Listener', 'Foodie'] },
      { name: 'John', avatar: 'https://i.pravatar.cc/150?u=2', vibes: ['Storyteller', 'Music Lover'] }
    ]
  },
  {
    id: '2',
    title: 'Bo-Kaap Rooftop Dinner',
    type: 'Come sit with us',
    curator: {
      name: 'Amina',
      avatar: 'https://picsum.photos/seed/amina/100/100',
      since: '2024',
      bio: "Cape Malay heritage and modern flavors."
    },
    date: 'Saturday, Feb 13',
    time: '18:30',
    endTime: '22:00',
    location: 'Bo-Kaap',
    price: 350,
    capacity: 6,
    spotsLeft: 2,
    image: 'https://images.unsplash.com/photo-1569058242252-62324e7ec990?auto=format&fit=crop&q=80&w=800',
    color: 'bg-primary',
    description: "An intimate rooftop dinner with views of Table Mountain. We'll explore the history of Cape Malay cuisine through five small plates.",
    whatsIncluded: ['5-course tasting menu', 'Rooftop views', 'History talk'],
    houseRules: ['Bring your own wine', 'Punctuality is appreciated'],
    confirmedGuests: []
  }
];